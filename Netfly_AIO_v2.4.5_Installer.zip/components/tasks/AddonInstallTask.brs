sub init()
    m.top.functionName = "execute"
end sub

sub execute()
    normalized = St_NormalizeUrl(m.top.url)
    if normalized = ""
        m.top.result = { ok: false, url: "", error: "The add-on address is not valid." }
        return
    end if
    manifestUrl = Addon_Url(normalized, "/manifest.json")
    manifest = Http_FetchJson(manifestUrl, 10000)
    if type(manifest) <> "roAssociativeArray"
        m.top.result = { ok: false, url: normalized, error: "The add-on manifest could not be loaded or was not valid JSON." }
        return
    end if

    supportsMedia = false
    if type(manifest.types) = "roArray"
        for each mediaType in manifest.types
            if mediaType = "movie" or mediaType = "series" then supportsMedia = true
        end for
    end if
    if not supportsMedia
        m.top.result = { ok: false, url: normalized, error: "This add-on does not declare movie or series support." }
        return
    end if

    hasKnownResource = false
    if type(manifest.resources) = "roArray"
        for each resource in manifest.resources
            resourceName = ""
            if IsStr(resource)
                resourceName = resource
            else if type(resource) = "roAssociativeArray"
                resourceName = Str_Of(resource.name)
            end if
            if resourceName = "catalog" or resourceName = "meta" or resourceName = "stream"
                hasKnownResource = true
            end if
        end for
    end if
    if not hasKnownResource
        m.top.result = { ok: false, url: normalized, error: "This manifest does not expose a Roku-supported Stremio Movies & TV resource." }
        return
    end if

    hints = manifest.behaviorHints
    requiresConfig = false
    if type(hints) = "roAssociativeArray" then requiresConfig = Bool_Of(hints.configurationRequired, false)
    if requiresConfig
        m.top.result = { ok: false, url: normalized, error: "This add-on requires account configuration before it can be installed. Configure it first, then add its final manifest URL." }
        return
    end if

    hasStream = false
    if type(manifest.resources) = "roArray"
        for each resource in manifest.resources
            resourceName = ""
            if IsStr(resource)
                resourceName = resource
            else if type(resource) = "roAssociativeArray"
                resourceName = Str_Of(resource.name)
            end if
            if resourceName = "stream" then hasStream = true
        end for
    end if
    m.top.result = {
        ok: true
        url: normalized
        name: Addon_Name(manifest, normalized)
        manifestUrl: manifestUrl
        hasStream: hasStream
        types: manifest.types
    }
end sub
