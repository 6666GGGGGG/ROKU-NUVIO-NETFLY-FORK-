sub init()
    m.top.functionName = "Storage_Run"
end sub

sub Storage_Run()
    if m.top.mode = "write"
        Storage_Commit(m.top.commands)
    else
        m.top.result = Storage_LoadAll()
    end if
end sub

function Storage_LoadAll() as object
    files = {}
    registry = {}

    ' Registry values are parsed here on a Task thread and handed to the
    ' SceneGraph render thread as ordinary associative-array data.
    sec = CreateObject("roRegistrySection", "nuviotv")
    if sec <> invalid
        for each key in sec.GetKeyList()
            raw = sec.Read(key)
            if raw <> ""
                value = ParseJson(raw)
                if value <> invalid then registry[key] = value
            end if
        end for
    end if

    fs = CreateObject("roFileSystem")
    if fs <> invalid
        ' Load tmp first so cachefs copies take precedence when both exist.
        for each root in ["tmp:/", "cachefs:/"]
            listing = fs.GetDirectoryListing(root)
            if listing <> invalid
                for each entry in listing
                    filename = entry
                    if Len(filename) > 5 and LCase(Right(filename, 5)) = ".json"
                        raw = ReadAsciiFile(root + filename)
                        if raw <> ""
                            value = ParseJson(raw)
                            if value <> invalid
                                name = Left(filename, Len(filename) - 5)
                                files[name] = value
                            end if
                        end if
                    end if
                end for
            end if
        end for
    end if

    return { files: files, registry: registry }
end function

sub Storage_Commit(commands as dynamic)
    if type(commands) <> "roArray" then return
    fs = CreateObject("roFileSystem")
    sec = CreateObject("roRegistrySection", "nuviotv")

    for each command in commands
        if type(command) = "roAssociativeArray"
            op = command.op

            if op = "fileWrite"
                name = command.name
                body = command.text
                cachePath = "cachefs:/" + name + ".json"
                tempPath = "tmp:/" + name + ".json"
                ok = WriteAsciiFile(cachePath, body)
                if ok and ReadAsciiFile(cachePath) = body
                    if fs <> invalid and fs.Exists(tempPath) then fs.Delete(tempPath)
                else
                    if fs <> invalid and fs.Exists(cachePath) then fs.Delete(cachePath)
                    WriteAsciiFile(tempPath, body)
                end if

            else if op = "fileDelete"
                name = command.name
                cachePath = "cachefs:/" + name + ".json"
                tempPath = "tmp:/" + name + ".json"
                if fs <> invalid
                    if fs.Exists(cachePath) then fs.Delete(cachePath)
                    if fs.Exists(tempPath) then fs.Delete(tempPath)
                else
                    DeleteFile(cachePath)
                    DeleteFile(tempPath)
                end if

            else if op = "registryWrite"
                if sec <> invalid
                    sec.Write(command.key, command.text)
                    sec.Flush()
                end if

            else if op = "registryDelete"
                if sec <> invalid and sec.Exists(command.key)
                    sec.Delete(command.key)
                    sec.Flush()
                end if
            end if
        end if
    end for
end sub
