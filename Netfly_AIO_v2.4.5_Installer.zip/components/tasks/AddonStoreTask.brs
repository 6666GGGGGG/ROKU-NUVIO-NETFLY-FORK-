sub init()
    m.top.functionName = "execute"
end sub

sub execute()
    ' Fetch the directory manifest first, then query a bounded set of catalogue
    ' endpoints concurrently. This keeps slow directory entries from blocking
    ' the complete store load for minutes on low-memory Roku devices.
    apiRoot = "https://stremio-addons.net/api"
    manifest = Http_FetchJson(apiRoot + "/manifest.json", 10000)
    if type(manifest) <> "roAssociativeArray"
        m.top.result = { ok: false, items: [], error: "Could not load the Stremio Addons catalogue manifest. Check the Roku internet connection and try again." }
        return
    end if
    if type(manifest.addonCatalogs) <> "roArray" or manifest.addonCatalogs.Count() = 0
        m.top.result = { ok: false, items: [], error: "The Stremio Addons manifest did not publish an addon_catalog resource." }
        return
    end if

    refs = []
    urls = []
    limit = manifest.addonCatalogs.Count()
    if limit > 8 then limit = 8
    for i = 0 to limit - 1
        cat = manifest.addonCatalogs[i]
        if type(cat) <> "roAssociativeArray" then continue for
        catalogType = Str_Of(cat["type"]).Trim()
        catalogId = Str_Of(cat.id).Trim()
        if catalogType = "" or catalogId = "" then continue for
        path = "/addon_catalog/" + catalogType.EncodeUriComponent() + "/" + catalogId.EncodeUriComponent() + ".json"
        refs.Push({ type: catalogType, id: catalogId })
        urls.Push(Addon_Url(apiRoot + "/manifest.json", path))
    end for
    if urls.Count() = 0
        m.top.result = { ok: false, items: [], error: "The Stremio Addons directory did not list any valid catalogues." }
        return
    end if

    fetched = Http_FetchHook(urls, 12000, 0, 4, invalid)
    items = []
    seen = {}
    failures = 0
    for i = 0 to urls.Count() - 1
        payload = fetched.data[i]
        if type(payload) <> "roAssociativeArray" or type(payload.addons) <> "roArray"
            failures = failures + 1
            continue for
        end if
        for each entry in payload.addons
            if type(entry) <> "roAssociativeArray" then continue for
            transportName = LCase(Str_Of(entry.transportName).Trim())
            if transportName <> "" and transportName <> "http" then continue for
            addonManifest = entry.manifest
            transportUrl = Str_Of(entry.transportUrl).Trim()
            if transportUrl = "" or type(addonManifest) <> "roAssociativeArray" then continue for
            normalized = St_NormalizeUrl(transportUrl)
            if normalized = "" then continue for
            key = LCase(normalized)
            if seen.DoesExist(key) then continue for

            supportsMedia = false
            if type(addonManifest.types) = "roArray"
                for each mediaType in addonManifest.types
                    if mediaType = "movie" or mediaType = "series" then supportsMedia = true
                end for
            end if
            if not supportsMedia then continue for
            hints = addonManifest.behaviorHints
            if type(hints) = "roAssociativeArray" and Bool_Of(hints.adult, false) then continue for

            name = Str_Of(addonManifest.name).Trim()
            if name = "" then name = normalized
            resources = []
            if type(addonManifest.resources) = "roArray"
                for each resource in addonManifest.resources
                    if IsStr(resource)
                        resources.Push(resource)
                    else if type(resource) = "roAssociativeArray"
                        resources.Push(Str_Of(resource.name))
                    end if
                end for
            end if
            requiresConfig = false
            configurable = false
            if type(hints) = "roAssociativeArray"
                requiresConfig = Bool_Of(hints.configurationRequired, false)
                configurable = Bool_Of(hints.configurable, false)
            end if
            configureUrl = ""
            if requiresConfig or configurable then configureUrl = Addon_Url(normalized, "/configure")
            items.Push({
                name: name
                description: Str_Of(addonManifest.description)
                url: normalized
                manifestUrl: Addon_Url(normalized, "/manifest.json")
                configureUrl: configureUrl
                requiresConfig: requiresConfig
                configurable: configurable
                version: Str_Of(addonManifest.version)
                logo: Str_Of(addonManifest.logo)
                id: Str_Of(addonManifest.id)
                resources: resources
                types: addonManifest.types
                source: "stremio-addons.net"
            })
            seen[key] = true
            if items.Count() >= 80 then exit for
        end for
        if items.Count() >= 80 then exit for
    end for

    if items.Count() = 0
        if failures > 0
            m.top.result = { ok: false, items: [], error: "The Stremio Addons directory responded, but its catalogue endpoints did not return data. Try again later." }
        else
            m.top.result = { ok: false, items: [], error: "The directory responded but currently has no compatible Movies & TV add-ons." }
        end if
    else
        m.top.result = { ok: true, items: items, error: "", attribution: "Community catalogue: stremio-addons.net" }
    end if
end sub
