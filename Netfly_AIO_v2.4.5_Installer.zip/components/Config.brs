function Config_NuvioServer() as string
    return "https://api.nuvio.tv"
end function

function Config_NuvioWeb() as string
    return "https://nuvio.tv"
end function

function Config_TmdbKey() as string
    return "01926d2187b6a5d861eefc750e9df3e3"
end function

function Config_TraktClientId() as string
    return "5783db7c46a5b22f072d4b224f9bd7dc2cbaba66dbe3515d1feb59e3ca72394c"
end function

function Config_TraktClientSecret() as string
    return "bf6e7561dafee902f5a2a67d2b31feac1563632f331f3958c978aff6389ea384"
end function

function Config_SimklClientId() as string
    return "dc20e0db975583b15096267cee79cd23b1f56d4bd301ce3c51e4a96a49c834a6"
end function

function Config_MdbClientId() as string
    return "kMMZyv8qithmUSF5102U6HTAPEDqfHtNbn1W4gkz"
end function
