sub init()
    St_Migrate()
    m.storageReady = false
    m.bootReadyPending = false
    m.bootReadyDone = false
    m.storageLoadTask = invalid
    m.storageWriteTask = invalid
    m.top.backgroundColor = "0x0B080BFF"
    m.top.backgroundUri = ""
    m.appBg = m.top.findNode("appBg")
    m.hero = m.top.findNode("hero")
    m.hero.observeField("immersive", "onHeroImmersive")
    m.homePage = m.top.findNode("homePage")
    m.homeRows = m.top.findNode("homeRows")
    m.emptyState = m.top.findNode("emptyState")
    m.emptyTitle = m.top.findNode("emptyTitle")
    m.emptyBody = m.top.findNode("emptyBody")
    m.emptyQr = m.top.findNode("emptyQr")
    m.searchPage = m.top.findNode("searchPage")
    m.searchText = m.top.findNode("searchText")
    m.searchStatus = m.top.findNode("searchStatus")
    m.searchRows = m.top.findNode("searchRows")
    m.libraryPage = m.top.findNode("libraryPage")
    m.libraryRows = m.top.findNode("libraryRows")
    m.libraryEmpty = m.top.findNode("libraryEmpty")
    m.nav = m.top.findNode("nav")
    m.details = m.top.findNode("details")
    m.list = m.top.findNode("list")
    m.settings = m.top.findNode("settings")
    m.loginTimer = m.top.findNode("loginTimer")
    m.settingsOpen = false
    m.themeRefreshPending = false
    m.themeApplyTimer = invalid
    m.addonInstallTask = invalid
    m.login = invalid
    m.loginPoll = invalid
    m.accountTask = invalid
    m.profiles = m.top.findNode("profiles")
    m.player = m.top.findNode("player")
    m.playerVideo = m.player.video
    m.loading = m.top.findNode("loading")
    m.skeleton = m.top.findNode("skeleton")
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"
    m.spinner.poster.width = 96
    m.spinner.poster.height = 96
    m.skeleton.observeField("visible", "onSkeletonVisible")
    m.loadingText = m.top.findNode("loadingText")
    m.loadingHint = m.top.findNode("loadingHint")
    m.heroTimer = m.top.findNode("heroTimer")
    m.expanded = m.top.findNode("expanded")
    m.expandTimer = m.top.findNode("expandTimer")
    m.autoTimer = m.top.findNode("autoTimer")
    m.subsWait = m.top.findNode("subsWait")
    m.streamsScreen = m.top.findNode("streamsScreen")
    m.trailerPlayer = m.top.findNode("trailerPlayer")
    m.sheet = m.top.findNode("sheet")
    m.auth = m.top.findNode("auth")
    m.auth.observeField("event", "onAuthEvent")
    m.partyJoin = m.top.findNode("partyJoin")
    m.partyJoin.observeField("event", "onPartyJoinEvent")
    m.partyPanel = m.top.findNode("partyPanel")
    m.partyPanel.observeField("event", "onPartyPanelEvent")
    m.trackAuth = m.top.findNode("trackAuth")
    m.trackAuth.observeField("event", "onTrackAuthEvent")
    m.updatePrompt = m.top.findNode("updatePrompt")
    m.updatePrompt.observeField("event", "onUpdateEvent")
    m.toast = m.top.findNode("toast")
    m.sheet.observeField("chosen", "onSheetChosen")
    m.sheet.observeField("closed", "onSheetClosed")
    m.streamsOpen = false
    m.trailerOpen = false
    m.trailerTask = invalid
    m.cardTask = invalid
    m.cardItem = invalid
    m.searchTimer = m.top.findNode("searchTimer")
    m.top.findNode("searchHeading").font.size = 56
    L_Texts(["searchHeading", "searchHint", "searchStatus", "libraryEmpty", "loadingHint"])

    m.stack = []
    m.manifests = []
    m.catalogs = []
    m.addonStoreTask = invalid
    m.storeItems = []
    m.storeSearch = ""
    m.ctx = {}
    m.metaCache = {}
    m.metaCacheCount = 0
    m.page = "home"
    m.area = "page"
    m.detailsOpen = false
    m.homeLoaded = false
    m.needsReload = false
    m.busy = false
    m.lastSaved = 0
    m.kbKind = ""
    m.kbData = {}
    m.lastQuery = ""
    m.heroItem = invalid
    m.heroTask = invalid
    m.catalogTask = invalid
    m.metaTask = invalid
    m.streamTask = invalid
    m.subtitleTask = invalid
    m.importTask = invalid
    m.searchTask = invalid
    m.autoPlay = false
    m.searchFocus = "keyboard"
    m.searchRoot = CreateObject("roSGNode", "ContentNode")

    m.global.addFields({ accent: "0xE50914FF", themeBg: "0x0B080BFF", themeSurface: "0x191015FF", themeSurface2: "0x26171DFF", storageCache: {}, storageRegistry: {}, storageQueue: [], storageVersion: 0 })
    m.global.observeField("storageVersion", "onStorageQueue")
    startStorageLoad()
    m.global.addField("focusCard", "node", true)
    m.global.addFields({ expandShift: 0.0, expandIndex: -1, syncDirty: 0, corners: "auto" })
    Mask_Global()
    m.global.observeField("syncDirty", "onSyncDirty")
    m.global.addField("activity", "boolean", true)
    m.global.addField("gifUrl", "string", false)
    m.global.addField("gifCard", "node", true)
    m.global.observeField("gifCard", "onGifCard")
    m.gifLayer = m.top.findNode("gifLayer")
    m.gifArt = m.top.findNode("gifArt")
    m.gifRing = m.top.findNode("gifRing")
    m.gifArt.observeField("state", "onGifArtState")
    m.gifTimer = m.top.createChild("Timer")
    m.gifTimer.duration = 0.45
    m.gifTimer.repeat = false
    m.gifTimer.observeField("fire", "Gif_Show")
    m.gifWait = m.top.createChild("Timer")
    m.gifWait.duration = 7
    m.gifWait.repeat = false
    m.gifWait.observeField("fire", "onGifWait")
    m.global.observeField("activity", "Ambient_Poke")
    m.ambient = m.top.findNode("ambient")
    m.ambient.observeField("closed", "Ambient_Close")
    m.ambientClock = CreateObject("roTimespan")
    m.ambientTimer = m.top.createChild("Timer")
    m.ambientTimer.duration = 10
    m.ambientTimer.repeat = true
    m.ambientTimer.observeField("fire", "onAmbientTimer")
    m.ambientTimer.control = "start"
    m.pushTimer = m.top.createChild("Timer")
    m.pushTimer.duration = 8
    m.pushTimer.observeField("fire", "onPushTimer")
    m.progressTimer = m.top.createChild("Timer")
    m.progressTimer.duration = 300
    m.progressTimer.repeat = true
    m.progressTimer.observeField("fire", "onProgressTimer")
    m.progressTimer.control = "start"
    m.progressSoon = m.top.createChild("Timer")
    m.progressSoon.duration = 12
    m.progressSoon.observeField("fire", "onProgressTimer")
    m.global.addField("expandRow", "node", false)
    m.global.observeField("focusCard", "onFocusCard")
    m.expandTimer.observeField("fire", "onExpandTimer")
    m.autoTimer.observeField("fire", "onAutoTimer")
    m.subsWait.observeField("fire", "onSubsWait")
    m.streamsScreen.observeField("event", "onStreamsEvent")
    m.trailerPlayer.observeField("event", "onTrailerEvent")
    for each rows in [m.homeRows, m.searchRows, m.libraryRows]
        rows.rowLabelFont.size = 32
        rows.observeField("rowItemSelected", "onRowSelected")
        rows.observeField("rowItemFocused", "onRowFocused")
        rows.observeField("currFocusRow", "onRowsMove")
    end for

    m.keyboard = CreateObject("roSGNode", "MiniKeyboard")
    if m.keyboard = invalid then m.keyboard = CreateObject("roSGNode", "Keyboard")
    m.top.findNode("keyboardHolder").appendChild(m.keyboard)
    m.keyboard.observeField("text", "onSearchText")
    Disc_Setup()
    m.searchTimer.observeField("fire", "onSearchTimer")
    m.heroTimer.observeField("fire", "onHeroTimer")

    m.homeFocusPending = false
    m.homeLoadTimer = m.top.createChild("Timer")
    m.homeLoadTimer.duration = 20
    m.homeLoadTimer.repeat = false
    m.homeLoadTimer.observeField("fire", "onHomeLoadTimeout")
    m.nav.observeField("inputSerial", "onNavInput")
    m.nav.observeField("chosen", "onNavChosen")
    m.nav.observeField("leave", "onNavLeave")
    m.details.observeField("selected", "onDetailsSelected")
    m.details.observeField("back", "onDetailsBack")
    m.list.observeField("selected", "onListSelected")
    m.list.observeField("back", "onListBack")
    m.profiles.observeField("selected", "onProfileChosen")
    m.pinPad = m.top.findNode("pinPad")
    m.pinPad.observeField("pin", "onPinEntered")
    m.pinPad.observeField("cancel", "onPinCancel")
    m.settings.observeField("event", "onSettingsEvent")
    m.settings.observeField("back", "onSettingsBack")
    m.settings.observeField("leave", "onSettingsLeave")
    m.loginTimer.observeField("fire", "onLoginTimer")
    m.player.observeField("event", "onPlayerEvent")
    m.playerVideo.observeField("position", "onPlayerPosition")
    m.playerVideo.observeField("state", "onPlayerVideoState")
    m.scrobbleState = ""

    ' Wait for saved state before applying theme/profile or starting catalogues.
    m.bootReadyTimer = m.top.createChild("Timer")
    m.bootReadyTimer.duration = 0.25
    m.bootReadyTimer.repeat = false
    m.bootReadyTimer.observeField("fire", "onBootReady")
    m.bootReadyTimer.control = "start"
end sub

sub onBootReady()
    if m.bootReadyDone then return
    if not m.storageReady
        m.bootReadyPending = true
        return
    end if
    m.bootReadyPending = false
    m.bootReadyDone = true
    applyTheme()
    if Auth_ShouldGate()
        Auth_Open("onboarding")
    else
        Profile_Startup()
    end if

    ' Background services are deliberately staggered so they do not compete
    ' with first-screen layout and initial catalogue rendering.
    if m.serverDelayTimer = invalid
        m.serverDelayTimer = m.top.createChild("Timer")
        m.serverDelayTimer.duration = 18
        m.serverDelayTimer.repeat = false
        m.serverDelayTimer.observeField("fire", "onBootServerTimer")
        m.serverDelayTimer.control = "start"
    end if
    if m.updateDelayTimer = invalid
        m.updateDelayTimer = m.top.createChild("Timer")
        m.updateDelayTimer.duration = 60
        m.updateDelayTimer.repeat = false
        m.updateDelayTimer.observeField("fire", "onBootUpdateTimer")
        m.updateDelayTimer.control = "start"
    end if
end sub

sub onBootServerTimer()
    if m.server = invalid then startServer()
end sub

sub onBootUpdateTimer()
    if m.updateTask = invalid then Update_Start()
end sub

sub scheduleQuietSync()
    if St_Integrations().nuvioAccess = "" then return
    if m.syncDelayTimer = invalid
        m.syncDelayTimer = m.top.createChild("Timer")
        m.syncDelayTimer.duration = 20
        m.syncDelayTimer.repeat = false
        m.syncDelayTimer.observeField("fire", "onBootSyncTimer")
    end if
    m.syncDelayTimer.control = "stop"
    m.syncDelayTimer.control = "start"
end sub

sub onBootSyncTimer()
    if not m.profiles.visible and not m.auth.visible and not m.player.visible then startQuietSync()
end sub

sub onSyncDirty()
    if St_Integrations().nuvioAccess = "" then return
    m.pushTimer.control = "stop"
    m.pushTimer.control = "start"
end sub

sub onPushTimer()
    if m.accountTask <> invalid or m.pushTask <> invalid
        m.pushTimer.control = "start"
        return
    end if
    m.pushTask = CreateObject("roSGNode", "AccountTask")
    m.pushTask.mode = "nuvioPush"
    m.pushTask.observeField("result", "onPushDone")
    m.pushTask.control = "RUN"
end sub

sub onPushDone()
    m.pushTask = invalid
end sub

sub startServer()
    m.server = CreateObject("roSGNode", "ServerTask")
    m.server.observeField("changed", "onServerChanged")
    m.server.observeField("state", "onServerState")
    if m.serverNames <> invalid then m.server.addonNames = m.serverNames
    if m.catalogs <> invalid then m.server.catalogs = m.catalogs
    m.server.control = "RUN"
end sub

sub onServerState()
    if m.server = invalid then return
    st = m.server.state
    if st = "stop" or st = "done"
        m.server.unobserveField("changed")
        m.server.unobserveField("state")
        m.server = invalid
        if m.serverRestarts = invalid then m.serverRestarts = 0
        if m.serverRestarts < 20
            m.serverRestarts = m.serverRestarts + 1
            startServer()
        end if
    end if
end sub

sub applyTheme()
    applyThemePalette()
    if m.disc <> invalid then Disc_Location()
    Grid_Layout()
end sub

' Apply only colours and theme-facing node fields. This avoids rebuilding
' discovery/nav/layout state when the user only changes the palette.
sub applyThemePalette()
    m.prefs = St_Prefs()
    theme = St_ThemeConfig(Str_Of(St_Pref("themePreset")))
    bg = "0x" + theme.background + "FF"
    surface = "0x" + theme.surface + "FF"
    surface2 = "0x" + theme.surface2 + "FF"
    m.top.backgroundColor = bg
    if m.appBg <> invalid then m.appBg.color = bg
    if m.global.themeBg <> bg then m.global.themeBg = bg
    if m.global.themeSurface <> surface then m.global.themeSurface = surface
    if m.global.themeSurface2 <> surface2 then m.global.themeSurface2 = surface2
    m.hero.baseColor = bg
    m.accent = "0x" + m.prefs.accent + "FF"
    if m.global.accent <> m.accent then m.global.accent = m.accent
    m.list.accent = m.accent
    m.settings.accent = m.accent
    m.settings.background = bg
    m.settings.surface = surface
    m.settings.surface2 = surface2
    m.details.accent = m.accent
    m.details.background = bg
    detailsBg = m.details.findNode("screenBg")
    if detailsBg <> invalid then detailsBg.color = bg
    detailsHero = m.details.findNode("hero")
    if detailsHero <> invalid then detailsHero.baseColor = bg
    listBg = m.list.findNode("bg")
    if listBg <> invalid then listBg.color = surface
    streamsBg = m.streamsScreen.findNode("screenBg")
    if streamsBg <> invalid then streamsBg.color = surface
    profileBg = m.profiles.findNode("screenBg")
    if profileBg <> invalid then profileBg.color = bg
    profileGlow = m.profiles.findNode("glow")
    if profileGlow <> invalid then profileGlow.blendColor = m.accent
    m.sheet.accent = m.accent
    m.sheet.surface = surface
    m.sheet.surface2 = surface2
    m.player.accent = m.accent
    m.nav.accent = m.accent
    m.nav.surface = surface
    navModern = Bool_Of(St_Pref("navModern"), true)
    navBlur = Bool_Of(St_Pref("navBlur"), false)
    navCollapsed = Bool_Of(St_Pref("navCollapsed"), false)
    if m.nav.modern <> navModern then m.nav.modern = navModern
    if m.nav.blur <> navBlur then m.nav.blur = navBlur
    if m.nav.collapsed <> navCollapsed then m.nav.collapsed = navCollapsed
    m.streamsScreen.accent = m.accent
    performanceMode = Str_Of(St_Pref("performanceMode"))
    reduceMotion = Bool_Of(St_Pref("reduceMotion"), false)
    m.ui = {
        expandOn: Bool_Of(St_Pref("expandPoster"), true) and not reduceMotion and performanceMode <> "lite"
        expandDelay: ToInt(St_Pref("expandDelay"), 3)
        expandTrailer: Bool_Of(St_Pref("expandTrailer"), false) and not reduceMotion and performanceMode = "quality"
        expandMuted: Bool_Of(St_Pref("expandMuted"), true)
        trailerTarget: Str_Of(St_Pref("trailerTarget"))
    }
    if performanceMode = "lite" and m.ui.expandDelay < 5 then m.ui.expandDelay = 5
    if m.ui.expandDelay < 1 then m.ui.expandDelay = 1
    profile = St_ActiveProfile()
    profileName = Str_Glyphs(Str_Of(profile.name))
    profileColor = St_ProfileColor(St_ActiveProfileIndex())
    profileAvatar = Str_Of(profile.avatar)
    if m.nav.profileName <> profileName then m.nav.profileName = profileName
    if m.nav.profileColor <> profileColor then m.nav.profileColor = profileColor
    if m.nav.profileAvatar <> profileAvatar then m.nav.profileAvatar = profileAvatar
    if m.prefs.captions
        m.playerVideo.globalCaptionMode = "On"
    else
        m.playerVideo.globalCaptionMode = "Off"
    end if
end sub

sub scheduleThemeApply(refresh as boolean)
    if m.themeApplyTimer = invalid
        m.themeApplyTimer = m.top.createChild("Timer")
        m.themeApplyTimer.duration = 0.12
        m.themeApplyTimer.repeat = false
        m.themeApplyTimer.observeField("fire", "onThemeApplyTimer")
    end if
    if refresh then m.themeRefreshPending = true
    m.themeApplyTimer.control = "stop"
    m.themeApplyTimer.control = "start"
end sub

sub onThemeApplyTimer()
    applyThemePalette()
    if m.themeRefreshPending
        m.themeRefreshPending = false
        refreshSettings()
    end if
    focusCurrent()
end sub

sub showProfiles()
    list = []
    profiles = St_Profiles()
    for i = 0 to profiles.Count() - 1
        list.Push({ id: profiles[i].id, name: profiles[i].name, color: St_ProfileColor(i), avatar: Str_Of(profiles[i].avatar), pin: profiles[i].pin = true })
    end for
    m.profiles.profiles = list
    m.profiles.visible = true
    if not m.pinPad.visible then m.profiles.setFocus(true)
end sub

sub Profile_Startup()
    st = St_Settings()
    profiles = St_Profiles()
    idx = St_ProfileIndex(profiles, Str_Of(st.active))
    if not Bool_Of(st.rememberProfile, false) or idx < 0
        showProfiles()
        return
    end if
    if profiles[idx].pin = true and St_Integrations().nuvioAccess <> ""
        showProfiles()
        Pin_Open(profiles[idx])
        return
    end if
    Profile_Enter(profiles[idx].id)
end sub

sub onProfileChosen()
    pid = m.profiles.selected
    if pid = "__add"
        showKeyboard("pickerProfile", L("Nombre del perfil"), "", {})
        return
    end if
    profiles = St_Profiles()
    idx = St_ProfileIndex(profiles, pid)
    if idx >= 0 and profiles[idx].pin = true and St_Integrations().nuvioAccess <> ""
        Pin_Open(profiles[idx])
        return
    end if
    Profile_Enter(pid)
end sub

sub Pin_Open(profile as object)
    m.pinProfile = profile
    m.pinPad.name = Str_Of(profile.name)
    m.pinPad.error = ""
    m.pinPad.working = false
    m.pinPad.visible = true
    m.pinPad.setFocus(true)
end sub

sub Pin_Close()
    m.pinPad.visible = false
    m.pinTask = invalid
    m.profiles.setFocus(true)
end sub

sub onPinCancel()
    Pin_Close()
end sub

sub onPinEntered()
    if m.pinProfile = invalid or m.pinPad.pin = "" then return
    m.pinPad.working = true
    m.pinTask = CreateObject("roSGNode", "AccountTask")
    m.pinTask.mode = "verifyPin"
    m.pinTask.params = { remote: ToInt(m.pinProfile.remote, 0), pin: m.pinPad.pin }
    m.pinTask.observeField("result", "onPinVerified")
    m.pinTask.control = "RUN"
end sub

sub onPinVerified(event as object)
    task = event.getRoSGNode()
    if m.pinTask = invalid or not task.isSameNode(m.pinTask) then return
    m.pinTask = invalid
    r = task.result
    m.pinPad.working = false
    if r = invalid or r.ok <> true
        msg = L("No se pudo verificar el PIN. Intenta de nuevo.")
        if r <> invalid and Str_Of(r.error) <> "" then msg = r.error
        m.pinPad.error = msg
        return
    end if
    if r.unlocked = true
        pid = m.pinProfile.id
        m.pinPad.visible = false
        Profile_Enter(pid)
        return
    end if
    if ToInt(r.retry, 0) > 0
        m.pinPad.error = L("Perfil bloqueado. Intenta de nuevo en") + " " + ToInt(r.retry, 0).ToStr() + " s."
    else
        m.pinPad.error = L("PIN incorrecto. Intenta de nuevo.")
    end if
end sub

sub Profile_Enter(pid as string)
    changed = St_Settings().active <> pid or not m.homeLoaded
    St_SetActiveProfile(pid)
    m.profiles.visible = false
    applyTheme()
    if changed
        m.needsReload = true
        m.stack.Clear()
        m.list.visible = false
        closeDetails(false)
        m.homeRows.content = invalid
        m.homeRows.visible = false
        m.homeFocusPending = true
        m.area = "page"
        showPage("home")
        ' Keep the navigation rail focusable while the catalogue is loading.
        ' The Scene itself does not handle Up/Down/OK, so focusing it with an
        ' empty RowList makes the home screen appear frozen when providers are
        ' slow or unavailable.
        if not m.homeRows.isInFocusChain() and not m.nav.isInFocusChain() and not overlayOpen() then focusNav()
        scheduleQuietSync()
    else
        focusCurrent()
    end if
end sub

sub loadHome()
    applyTheme()
    if not Bool_Of(m.homeLoaded, false) then Progress_Soon()
    m.homeLoaded = true
    m.needsReload = false
    m.emptyState.visible = false
    m.loadingHint.visible = false
    hasRows = m.homeRows.content <> invalid and m.homeRows.content.getChildCount() > 0 and m.homeRows.visible
    if not hasRows
        m.homeRows.visible = false
        m.hero.visible = false
        m.skeleton.visible = m.page = "home"
        if m.homeLoadTimer <> invalid and m.page = "home" then m.homeLoadTimer.control = "start"
    else if m.homeLoadTimer <> invalid
        m.homeLoadTimer.control = "stop"
    end if
    if m.catalogTask <> invalid
        m.catalogTask.unobserveField("content")
        m.catalogTask.unobserveField("early")
        m.catalogTask.control = "STOP"
    end if
    m.catalogTask = CreateObject("roSGNode", "CatalogTask")
    m.catalogTask.observeField("early", "onCatalogsEarly")
    m.catalogTask.observeField("content", "onCatalogsLoaded")
    m.catalogTask.control = "RUN"
    if m.page = "home" and m.area = "page" and not overlayOpen()
        if hasRows
            m.hero.visible = true
            showHeroFor(getRowItem(m.homeRows, m.homeRows.rowItemFocused))
            focusPage()
        else
            ' Do not leave focus on MainScene while the Home RowList is empty.
            ' MainScene intentionally does not consume basic directional/OK
            ' input, so that focus state looks like a frozen Home screen.
            focusNav()
        end if
    end if
end sub

sub onHomeLoadTimeout()
    ' Do not leave the user staring at an endless skeleton if providers are
    ' unreachable. The catalogue task is allowed to finish; late results will
    ' replace this message through Home_Show().
    if m.page <> "home" or m.homeRows.visible or overlayOpen() then return
    if m.homeRows.content <> invalid and m.homeRows.content.getChildCount() > 0 then return
    m.skeleton.visible = false
    m.emptyTitle.text = L("Tus catálogos no cargaron")
    url = Net_ServerUrl()
    body = L("Tardó demasiado en responder")
    if url <> "" then body = body + chr(10) + chr(10) + L("Configuración desde el celular: ") + url
    m.emptyBody.text = body
    if url <> ""
        m.emptyQr.uri = Net_QrUri(url)
        m.emptyQr.visible = true
    else
        m.emptyQr.visible = false
    end if
    m.emptyState.visible = true
    if not m.nav.isInFocusChain() then focusNav()
end sub

sub onSkeletonVisible()
    anim = m.top.findNode("skeletonPulse")
    if m.skeleton.visible then anim.control = "start" else anim.control = "stop"
end sub

sub Home_TakeTask(task as object)
    manifests = task.manifests
    catalogs = task.catalogs
    if manifests = invalid or manifests.Count() = 0 then return
    m.manifests = manifests
    if catalogs <> invalid then m.catalogs = catalogs
    names = {}
    for each entry in m.manifests
        names[entry.base] = entry.name
    end for
    m.serverNames = names
    if m.server <> invalid
        m.server.addonNames = names
        m.server.catalogs = m.catalogs
    end if
end sub

sub onCatalogsEarly(event as object)
    task = event.getRoSGNode()
    if m.catalogTask = invalid or not task.isSameNode(m.catalogTask) then return
    Home_TakeTask(task)
    content = task.early
    if content = invalid or content.getChildCount() = 0 then return
    Home_Show(content)
end sub

sub onCatalogsLoaded(event as object)
    task = event.getRoSGNode()
    if m.catalogTask = invalid or not task.isSameNode(m.catalogTask) then return
    if m.homeLoadTimer <> invalid then m.homeLoadTimer.control = "stop"
    Home_TakeTask(task)
    if task.manifests = invalid or task.manifests.Count() = 0
        m.manifests = []
        m.catalogs = []
    end if
    content = task.content
    m.skeleton.visible = false
    if content <> invalid and content.getChildCount() > 0
        Home_Show(content)
        ' Posters load directly through PosterItem. Avoid launching a bulk
        ' disk-cache download from the Home completion callback: on Roku this
        ' can compete with RowList layout and make the whole Home page appear
        ' unresponsive. Poster caching remains an optional manual feature.
    else
        m.homeRows.content = content
        m.homeRows.visible = false
        m.hero.visible = false
        showEmptyState(task.addonCount, task.failed)
    end if
    if m.page = "library" then buildLibrary()
end sub

function Home_RowKey(row as object) as string
    if row = invalid then return ""
    if row.id = "cw" then return "cw"
    if row.hasField("key") then return row.key
    return row.title
end function

function Home_RowSig(row as object) as string
    if row = invalid then return ""
    n = row.getChildCount()
    parts = [n.ToStr(), row.title]
    for i = 0 to n - 1
        if i > 5 then exit for
        c = row.getChild(i)
        if c.hasField("remote") then parts.Push(c.remote) else parts.Push(c.HDPosterUrl)
    end for
    return parts.Join("|")
end function

sub Poster_Localize(root as object)
    if root = invalid or m.posterMap = invalid then return
    for i = 0 to root.getChildCount() - 1
        row = root.getChild(i)
        for j = 0 to row.getChildCount() - 1
            item = row.getChild(j)
            local = m.posterMap[item.HDPosterUrl]
            if local <> invalid
                if not item.hasField("remote") then item.addFields({ remote: item.HDPosterUrl }) else item.remote = item.HDPosterUrl
                item.HDPosterUrl = local
            end if
        end for
    end for
end sub

sub Poster_Check()
    ' Poster-cache file validation is performed by PosterCacheTask. Never
    ' instantiate roFileSystem from the SceneGraph render thread.
    return
end sub

sub Poster_Cache(root as object)
    if root = invalid then return
    urls = []
    for i = 0 to root.getChildCount() - 1
        row = root.getChild(i)
        for j = 0 to row.getChildCount() - 1
            if j >= 12 then exit for
            u = row.getChild(j).HDPosterUrl
            if Left(u, 4) = "http" then urls.Push(u)
        end for
    end for
    if urls.Count() = 0 then return
    Poster_Stop()
    m.posterTask = CreateObject("roSGNode", "PosterCacheTask")
    m.posterTask.urls = urls
    m.posterTask.observeField("result", "onPosterCache")
    m.posterTask.control = "RUN"
end sub

sub Poster_Stop()
    if m.posterTask = invalid then return
    m.posterTask.unobserveField("result")
    m.posterTask.cancel = true
    m.posterTask = invalid
end sub

sub onPosterCache(event as object)
    task = event.getRoSGNode()
    if m.posterTask = invalid or not task.isSameNode(m.posterTask) then return
    m.posterTask = invalid
    found = task.result
    if type(found) <> "roAssociativeArray" then return
    if m.posterMap = invalid then m.posterMap = {}
    for each k in found
        m.posterMap[k] = found[k]
    end for
end sub

sub Home_Show(content as object)
    if m.homeLoadTimer <> invalid then m.homeLoadTimer.control = "stop"
    Poster_Localize(content)
    content = Home_Decorate(content)
    m.skeleton.visible = false
    m.emptyState.visible = false
    old = m.homeRows.content
    focused = m.homeRows.isInFocusChain()
    engaged = old <> invalid and old.getChildCount() > 0 and m.homeRows.visible
    if not engaged
        m.homeRows.content = content
        applyRowSizes(m.homeRows)
        m.homeRows.visible = true
        if m.page = "home"
            m.hero.visible = true
            showHeroFor(getRowItem(m.homeRows, [0, 0]))
        end if
        if m.homeFocusPending and m.page = "home" and m.area = "nav"
            m.homeFocusPending = false
            m.area = "page"
            focusPage()
        else if m.area = "page" and not overlayOpen()
            focusPage()
        end if
        return
    end if
    oldKeys = []
    for i = 0 to old.getChildCount() - 1
        oldKeys.Push(Home_RowKey(old.getChild(i)))
    end for
    newRows = []
    for i = 0 to content.getChildCount() - 1
        newRows.Push(content.getChild(i))
    end for
    prefix = oldKeys.Count() <= newRows.Count()
    if prefix
        for i = 0 to oldKeys.Count() - 1
            if oldKeys[i] <> Home_RowKey(newRows[i]) then prefix = false
        end for
    end if
    focus = m.homeRows.rowItemFocused
    focusKey = ""
    if type(focus) = "roArray" and focus.Count() > 0 and focus[0] < oldKeys.Count() then focusKey = oldKeys[focus[0]]
    if prefix
        for i = oldKeys.Count() to newRows.Count() - 1
            old.appendChild(newRows[i])
        end for
        focusRow = -1
        if type(focus) = "roArray" and focus.Count() > 0 and focused then focusRow = focus[0]
        for i = 0 to oldKeys.Count() - 1
            if i <> focusRow and Home_RowSig(old.getChild(i)) <> Home_RowSig(newRows[i]) then old.replaceChild(newRows[i], i)
        end for
        applyRowSizes(m.homeRows)
        if m.homeFocusPending and m.page = "home" and m.area = "nav"
            m.homeFocusPending = false
            m.area = "page"
            focusPage()
        else
            Home_Refocus()
        end if
        return
    end if
    m.homeRows.content = content
    applyRowSizes(m.homeRows)
    target = 0
    for i = 0 to newRows.Count() - 1
        if Home_RowKey(newRows[i]) = focusKey then target = i
    end for
    m.homeRows.jumpToRowItem = [target, 0]
    if focused then m.homeRows.setFocus(true)
    if m.homeFocusPending and m.page = "home" and m.area = "nav"
        m.homeFocusPending = false
        m.area = "page"
        focusPage()
    else
        Home_Refocus()
    end if
end sub

sub Home_Refocus()
    if m.page <> "home" or m.area <> "page" or overlayOpen() or m.settingsOpen then return
    if m.homeRows.isInFocusChain() then return
    focusPage()
end sub

sub showEmptyState(addonCount as integer, failed as integer)
    url = Net_ServerUrl()
    if addonCount = 0
        m.emptyTitle.text = L("Aún no tienes addons")
        body = L("Conecta tu celular al mismo wifi que el Roku, abre el navegador y entra a:") + chr(10) + url + chr(10) + chr(10)
        body = body + L("Desde ahí puedes agregar addons, importar colecciones y configurar todo.")
    else if failed >= addonCount
        m.emptyTitle.text = L("No se pudo conectar con tus addons")
        body = L("Ninguno de tus ") + addonCount.ToStr() + L(" addons respondió. Revisa que el Roku tenga internet y que las direcciones sean correctas.") + chr(10) + chr(10)
        body = body + L("Configuración desde el celular: ") + url
    else
        problems = []
        for each c in m.catalogs
            status = Str_Of(c.status)
            if status <> "" and status <> "ok" and problems.Count() < 4 then problems.Push(c.name + " (" + TypePlural(c.kind) + "): " + status)
        end for
        if problems.Count() > 0
            m.emptyTitle.text = L("Tus catálogos no cargaron")
            body = problems.Join(chr(10)) + chr(10) + chr(10)
        else
            m.emptyTitle.text = L("Tus addons no tienen catálogos visibles")
            body = L("Puede que todos los catálogos estén ocultos o que tus addons solo den enlaces. Agrega un addon de catálogos o revisa Ajustes > Catálogos.") + chr(10) + chr(10)
        end if
        body = body + L("Configuración desde el celular: ") + url
    end if
    m.emptyBody.text = body
    if url <> "" then m.emptyQr.uri = Net_QrUri(url)
    m.emptyState.visible = true
end sub

function overlayOpen() as boolean
    return m.ambient.active or m.sheet.visible or m.updatePrompt.visible or m.auth.visible or m.trackAuth.visible or m.partyPanel.visible or m.partyJoin.visible or m.player.visible or m.trailerOpen or m.profiles.visible or m.streamsOpen or m.stack.Count() > 0 or m.detailsOpen or m.settingsOpen
end function

sub focusCurrent()
    if Bool_Of(m.immersiveOn, false) then Hero_EndImmersive()
    if m.top.dialog <> invalid then return
    if m.ambient.active
        m.ambient.setFocus(true)
        return
    end if
    if m.sheet.visible
        m.sheet.setFocus(true)
    else if m.updatePrompt.visible
        m.updatePrompt.setFocus(true)
    else if m.auth.visible
        m.auth.setFocus(true)
    else if m.trackAuth.visible
        m.trackAuth.setFocus(true)
    else if m.partyPanel.visible
        m.partyPanel.setFocus(true)
    else if m.partyJoin.visible
        m.partyJoin.setFocus(true)
    else if m.trailerOpen
        m.trailerPlayer.setFocus(true)
    else if m.player.visible
        m.player.setFocus(true)
    else if m.streamsOpen
        m.streamsScreen.setFocus(true)
    else if m.profiles.visible
        m.profiles.setFocus(true)
    else if m.stack.Count() > 0
        m.list.setFocus(true)
    else if m.settingsOpen
        m.settings.setFocus(true)
    else if m.detailsOpen and not m.details.visible and m.ctx <> invalid and Bool_Of(m.ctx.direct, false)
        closeDetails(true)
    else if m.detailsOpen
        m.details.setFocus(true)
    else if m.area = "nav"
        m.nav.setFocus(true)
    else
        focusPage()
    end if
end sub

sub Toast_Show(text as string)
    m.toast.text = text
end sub

sub focusNav()
    hideExpanded()
    m.area = "nav"
    m.nav.setFocus(true)
end sub

sub onNavInput()
    ' Any explicit remote movement in the rail cancels the automatic handoff
    ' to Home cards, so a slow catalogue response cannot steal user focus.
    m.homeFocusPending = false
end sub

sub onNavLeave()
    m.homeFocusPending = false
    if m.settingsOpen
        m.settings.setFocus(true)
        return
    end if
    m.area = "page"
    focusPage()
end sub

sub onSettingsLeave()
    m.nav.setFocus(true)
end sub

sub onNavChosen()
    choice = m.nav.chosen
    if m.settingsOpen and choice <> "settings"
        m.settingsOpen = false
        m.settings.visible = false
    end if
    if choice = "profile"
        showProfiles()
    else if choice = "settings"
        openSettings()
    else if choice = "store"
        m.nav.active = "store"
        m.area = "nav"
        openMenu("addonStore", {})
    else
        m.area = "page"
        showPage(choice)
    end if
end sub

function getRowItem(rows as object, cell as dynamic) as dynamic
    if type(cell) <> "roArray" or cell.Count() < 2 then return invalid
    root = rows.content
    if root = invalid then return invalid
    row = root.getChild(cell[0])
    if row = invalid then return invalid
    return row.getChild(cell[1])
end function

sub onRowsMove(event as object)
    if not m.gifLayer.visible and m.gifArt.uri = "" then return
    rows = event.getRoSGNode()
    focus = rows.rowItemFocused
    if type(focus) <> "roArray" or focus.Count() < 1 then return
    if Abs(event.getData() - focus[0]) > 0.02 then Gif_Hide()
end sub

sub onRowFocused(event as object)
    Ambient_Poke()
    Gif_Hide()
    if m.global.gifCard <> invalid then m.gifTimer.control = "start"
    hideExpanded()
    rows = event.getRoSGNode()
    if rows.isSameNode(m.searchRows) then return
    showHeroFor(getRowItem(rows, rows.rowItemFocused))
end sub

sub onRowSelected(event as object)
    if m.busy then return
    rows = event.getRoSGNode()
    if rows.isSameNode(m.searchRows) and Str_Of(m.lastQuery) <> "" then St_AddSearch(m.lastQuery)
    item = getRowItem(rows, rows.rowItemSelected)
    if item = invalid then return
    if item.itemType = "seeall"
        try
            Grid_SeeAll(item)
        catch e
            Grid_Error(e)
        end try
        return
    end if
    if item.itemType = "folder"
        openFolder(item)
        return
    end if
    focus = rows.rowItemSelected
    row = invalid
    if type(focus) = "roArray" and rows.content <> invalid then row = rows.content.getChild(focus[0])
    if row <> invalid and row.id = "cw"
        Continue_Play(item, "play")
        return
    end if
    openDetails(item)
end sub

sub Continue_Play(item as object, action as string)
    openDetails(item)
    m.details.visible = false
    m.ctx.direct = true
    runDetailAction(action)
end sub

sub openFolder(item as object)
    if not item.hasField("folder") then return
    m.folderGrid = false
    Folder_Load(item.title, item.folder)
end sub

sub Folder_Load(title as string, folder as object)
    hideExpanded()
    showBusy(L("Cargando..."))
    m.folderTitle = title
    task = CreateObject("roSGNode", "CatalogTask")
    task.baseManifests = m.manifests
    task.folder = folder
    task.observeField("content", "onFolderLoaded")
    task.control = "RUN"
    m.folderTask = task
end sub

sub onFolderLoaded(event as object)
    task = event.getRoSGNode()
    if m.folderTask = invalid or not task.isSameNode(m.folderTask) then return
    m.folderTask = invalid
    hideBusy()
    grid = Bool_Of(m.folderGrid, false)
    m.folderGrid = false
    root = task.content
    fails = task.folderFails
    detail = ""
    if type(fails) = "roArray" and fails.Count() > 0 then detail = fails.Join(chr(10))
    if root = invalid or root.getChildCount() = 0
        text = L("Esta carpeta no tiene catálogos de tus addons instalados.")
        if detail <> "" then text = L("No se pudo cargar:") + chr(10) + detail
        showMessage(m.folderTitle, text)
        return
    end if
    if detail <> "" then Toast_Show(L("No se pudo cargar:") + " " + fails.Join(", "))
    try
        m.libraryRows.content = invalid
        m.libraryGrid = grid
        Grid_Layout()
        m.libraryRows.content = root
        applyRowSizes(m.libraryRows)
        m.area = "page"
        showPage("folder")
    catch e
        Grid_Error(e)
    end try
end sub

sub Grid_Error(e as object)
    hideBusy()
    where = ""
    if type(e.backtrace) = "roArray" and e.backtrace.Count() > 0
        last = e.backtrace[e.backtrace.Count() - 1]
        if type(last) = "roAssociativeArray" then where = Str_Of(last.function) + " · " + Str_Any(last.line_number)
    end if
    showMessage(L("Ver todo"), Str_Of(e.message) + chr(10) + where)
end sub

sub showHeroFor(item as dynamic)
    if item = invalid then return
    Home_HeroState()
    if item.itemType = "seeall" then return
    if item.itemType = "folder"
        m.heroItem = item
        m.heroTimer.control = "stop"
        hide = item.hasField("hideTitle") and item.hideTitle = true
        title = item.title
        line = item.metaLine
        if hide
            title = ""
            line = ""
        end if
        logo = ""
        if item.hasField("logo") then logo = item.logo
        m.hero.data = { title: title, logo: logo, background: item.background, rating: "", metaLine: line, description: "" }
        video = ""
        if item.hasField("heroVideo") then video = item.heroVideo
        hasGif = item.hasField("gif") and item.gif <> ""
        if video <> "" and not hasGif and m.page = "home"
            m.heroTrailerOn = true
            m.hero.trailer = { url: video }
        else if Bool_Of(m.heroTrailerOn, false)
            m.heroTrailerOn = false
            m.hero.trailer = {}
        end if
        return
    end if
    if Bool_Of(m.heroTrailerOn, false)
        if m.cardItem = invalid or not m.cardItem.isSameNode(item)
            m.heroTrailerOn = false
            m.hero.trailer = {}
        end if
    end if
    m.heroItem = item
    cached = m.metaCache[item.metaId]
    d = heroData(item, cached)
    if cached = invalid
        if m.logoCache = invalid then m.logoCache = {}
        quick = m.logoCache[item.metaId]
        if quick <> invalid and quick <> ""
            d.logo = quick
        else if quick = invalid
            d.logoPending = true
            Logo_Start(item)
        end if
    end if
    m.hero.data = d
    m.heroTimer.control = "stop"
    if m.metaCache[item.metaId] = invalid then m.heroTimer.control = "start"
end sub

function heroData(item as object, meta as dynamic) as object
    logo = item.logo
    background = item.background
    if background = "" then background = item.HDPosterUrl
    rating = item.rating
    metaLine = item.metaLine
    description = item.description
    title = item.title
    if Left(item.metaId, 2) = "tt" and logo = "" then logo = Img_Logo(item.metaId)
    if meta <> invalid
        if Str_Of(meta.logo) <> "" then logo = meta.logo
        if item.background = "" and Str_Of(meta.background) <> "" then background = meta.background
        if rating = "" then rating = Str_Of(meta.imdbRating)
        if description = "" or item.videoId <> "" then description = Str_OneLine(meta.description)
        if title = "" then title = Str_Of(meta.name)
        line = Meta_Line(item.itemType, meta)
        if item.videoId = "" and Len(line) > Len(metaLine) then metaLine = line
    end if
    if m.logoCache <> invalid and Str_Of(m.logoCache[item.metaId]) <> "" then logo = m.logoCache[item.metaId]
    if item.videoId <> "" and item.episodeLabel <> "" then metaLine = item.metaLine
    if item.hasField("badge") and item.badge <> "" then metaLine = Cw_HeroLine(item, meta)
    if not Bool_Of(St_Pref("homeRatings"), true) then rating = ""
    return { title: title, logo: logo, background: background, rating: rating, metaLine: metaLine, description: description }
end function

function Cw_HeroLine(item as object, meta as dynamic) as string
    parts = []
    episode = [item.kicker, item.subtitle]
    if item.subtitle = "" then episode = [item.kicker]
    first = episode.Join("  ·  ").Trim()
    if item.kicker = "" then first = TypeLabel(item.itemType)
    parts.Push(first)
    if meta <> invalid
        if type(meta.genres) = "roArray" and meta.genres.Count() > 0 and IsStr(meta.genres[0]) then parts.Push(meta.genres[0])
        year = Str_Of(meta.releaseInfo)
        if Len(year) >= 4 then parts.Push(Left(year, 4))
    end if
    parts.Push(UCase(item.badge))
    return parts.Join("  ·  ")
end function

function Meta_Line(kind as string, meta as object) as string
    parts = [TypeLabel(kind)]
    year = Str_Of(meta.releaseInfo)
    if year <> "" then parts.Push(year)
    if type(meta.genres) = "roArray" and meta.genres.Count() > 0 then parts.Push(meta.genres.Join(", "))
    runtime = Str_Of(meta.runtime)
    if runtime <> "" then parts.Push(runtime)
    return parts.Join("  ·  ")
end function

sub onHeroTimer()
    item = m.heroItem
    if item = invalid or item.itemType = "folder" then return
    if m.metaCache[item.metaId] <> invalid then return
    if m.manifests.Count() = 0
        m.hero.data = heroData(item, invalid)
        return
    end if
    m.heroTask = CreateObject("roSGNode", "MetaTask")
    m.heroTask.manifests = m.manifests
    m.heroTask.kind = item.itemType
    m.heroTask.metaId = item.metaId
    m.heroTask.observeField("meta", "onHeroMeta")
    m.heroTask.control = "RUN"
end sub

sub onHeroMeta(event as object)
    task = event.getRoSGNode()
    meta = task.meta
    if meta = invalid
        if m.heroItem <> invalid and m.heroItem.metaId = task.metaId then m.hero.data = heroData(m.heroItem, invalid)
        return
    end if
    cacheMeta(task.metaId, meta)
    if m.heroItem <> invalid and m.heroItem.metaId = task.metaId
        m.hero.data = heroData(m.heroItem, meta)
    end if
end sub

sub cacheMeta(id as string, meta as object)
    if m.metaCacheCount > 80
        m.metaCache = {}
        m.metaCacheCount = 0
    end if
    if m.metaCache[id] = invalid then m.metaCacheCount = m.metaCacheCount + 1
    m.metaCache[id] = meta
end sub

sub showBusy(text as string)
    m.busy = true
    m.loadingText.text = text
    m.loadingHint.visible = true
    m.loading.visible = true
    m.spinner.control = "start"
end sub

sub hideBusy()
    m.busy = false
    m.loading.visible = false
    m.spinner.control = "stop"
end sub

sub cancelBusy()
    m.folderTask = invalid
    m.metaTask = invalid
    m.streamTask = invalid
    m.importTask = invalid
    if m.addonStoreTask <> invalid
        m.addonStoreTask.control = "STOP"
        m.addonStoreTask = invalid
    end if
    if m.addonInstallTask <> invalid
        m.addonInstallTask.control = "STOP"
        m.addonInstallTask = invalid
    end if
    m.autoPlay = false
    m.autoTimer.control = "stop"
    if m.ctx <> invalid and m.ctx.DoesExist("decided") then m.ctx.decided = true
    if m.player.visible and m.playerVideo.state <> "playing" and m.playerVideo.state <> "paused"
        hideBusy()
        closePlayer(false)
        return
    end if
    m.searchFocus = "keyboard"
    m.searchRoot = CreateObject("roSGNode", "ContentNode")
    hideBusy()
    focusCurrent()
end sub

sub onExternalInput()
    info = m.top.externalInput
    if info = invalid then return
    if not St_AddAddon(info.addon_url) then return
    reloadWhenIdle()
end sub

sub reloadWhenIdle()
    if not overlayOpen() and not m.busy
        loadHome()
    else
        m.needsReload = true
        if m.stack.Count() > 0 and not m.player.visible then renderMenu(m.stack.Peek().focus)
    end if
end sub

sub onServerChanged()
    what = m.server.changed
    if what = "search"
        if m.player.visible then return
        m.stack.Clear()
        m.list.visible = false
        closeDetails(false)
        m.profiles.visible = false
        m.area = "page"
        showPage("search")
        m.keyboard.text = m.server.searchQuery
        runSearch(m.server.searchQuery)
        St_AddSearch(m.server.searchQuery)
        m.searchFocus = "results"
        return
    end if
    if what = "nuvioLogin"
        if m.auth.visible
            Auth_Approved()
            return
        end if
        Toast_Show(L("Sesión iniciada. Sincronizando con Nuvio..."))
        m.syncToast = true
        startQuietSync()
        return
    end if
    if what = "theme"
        applyTheme()
        refreshSettings()
        if m.stack.Count() > 0 and not m.player.visible then renderMenu(m.stack.Peek().focus)
        return
    end if
    reloadWhenIdle()
end sub

sub showKeyboard(kind as string, title as string, text as string, data as object)
    m.kbKind = kind
    m.kbData = data
    dlg = CreateObject("roSGNode", "KeyboardDialog")
    dlg.title = title
    dlg.buttons = [L("Aceptar"), L("Cancelar")]
    dlg.observeFieldScoped("buttonSelected", "onKeyboardButton")
    dlg.observeFieldScoped("wasClosed", "onDialogClosed")
    m.top.dialog = dlg
    dlg.text = text
    dlg.keyboard.textEditBox.maxTextLength = 600
    dlg.keyboard.textEditBox.cursorPosition = Len(text)
end sub

sub onKeyboardButton()
    dlg = m.top.dialog
    if dlg = invalid then return
    choice = dlg.buttonSelected
    text = Kb_Text(dlg)
    dlg.close = true
    if choice <> 0 then return
    if text = "" and m.kbKind <> "regex" and m.kbKind <> "customPoster" and m.kbKind <> "integKey" and m.kbKind <> "srvPass" and m.kbKind <> "debKey" then return
    handleKeyboard(m.kbKind, text, m.kbData)
end sub

sub showMessage(title as string, text as string)
    hideBusy()
    Sheet_Open({ title: title, subtitle: text, items: [{ id: "ok", label: L("Aceptar") }] }, "message", invalid)
end sub

sub onMessageButton()
    if m.top.dialog <> invalid then m.top.dialog.close = true
    if Bool_Of(m.exitAfterDialog, false) then m.top.exitApp = true
end sub

sub onDialogClosed(event as object)
    closed = event.getRoSGNode()
    current = m.top.dialog
    if current <> invalid and not current.isSameNode(closed) then return
    m.top.dialog = invalid
    focusCurrent()
end sub

sub startImport(source as string)
    showBusy(L("Importando colección..."))
    m.importTask = CreateObject("roSGNode", "ImportTask")
    m.importTask.source = source
    m.importTask.observeField("added", "onImportDone")
    m.importTask.control = "RUN"
end sub

sub onImportDone(event as object)
    task = event.getRoSGNode()
    if m.importTask = invalid or not task.isSameNode(m.importTask) then return
    m.importTask = invalid
    hideBusy()
    added = task.added
    if added > 0
        m.needsReload = true
        if m.stack.Count() > 0 then renderMenu(m.stack.Peek().focus)
        countText = added.ToStr() + " addons"
        if added = 1 then countText = "1 addon"
        showMessage(L("Colección importada"), L("Se agregó ") + countText + L(". Los catálogos se recargan al volver al inicio."))
    else
        showMessage(L("Sin cambios"), L("No se encontraron addons nuevos en esa colección. Revisa que la dirección del .json sea correcta."))
    end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    Ambient_Poke()
    if m.ambient.active
        if press then Ambient_Close()
        return true
    end if
    if Bool_Of(m.immersiveOn, false)
        if press then Hero_EndImmersive()
        return true
    end if
    if not press then return false
    if m.busy
        if key = "back" then cancelBusy()
        return true
    end if
    if key = "back" and m.profiles.visible and Bool_Of(m.homeLoaded, false)
        m.profiles.visible = false
        focusCurrent()
        return true
    end if
    if overlayOpen() then return false
    if m.area = "nav"
        if key = "back" and m.page <> "home"
            m.area = "page"
            showPage("home")
            return true
        end if
        if key = "options"
            openSettings()
            return true
        end if
        return false
    end if
    if key = "options"
        Options_Open()
        return true
    end if
    if m.page = "search" then return searchKey(key)
    if m.page = "discover" then return Disc_Key(key)
    if m.page = "folder" and key = "back"
        m.area = "page"
        showPage("home")
        return true
    end if
    if key = "left" or key = "back"
        focusNav()
        return true
    end if
    return false
end function

function activeRows() as dynamic
    if m.page = "home" then return m.homeRows
    if m.page = "library" or m.page = "folder" then return m.libraryRows
    if m.page = "search" then return m.searchRows
    if m.page = "discover" then return m.discoverRows
    return invalid
end function

sub onFocusCard()
    if Bool_Of(m.immersiveOn, false) then return
    hideExpanded()
    if m.ui = invalid or m.page = "library" or m.page = "search" or m.page = "discover" then return
    if not m.ui.expandOn and not m.ui.expandTrailer then return
    m.expandTimer.duration = m.ui.expandDelay
    m.expandTimer.control = "start"
end sub

sub hideExpanded()
    m.expandTimer.control = "stop"
    m.cardTask = invalid
    m.cardItem = invalid
    if Bool_Of(m.heroTrailerOn, false)
        m.heroTrailerOn = false
        m.hero.trailer = {}
    end if
    if Bool_Of(m.immersiveOn, false) then Rows_Restore()
    if m.expanded.open then m.expanded.open = false
    if m.expandRows <> invalid
        m.expandRows.focusBitmapBlendColor = "0xFFFFFFFF"
        m.expandRows = invalid
    end if
end sub

sub onExpandTimer()
    card = m.global.focusCard
    if card = invalid or m.busy or m.area <> "page" or overlayOpen() then return
    if not card.itemHasFocus then return
    rows = activeRows()
    if rows = invalid or not rows.isInFocusChain() then return
    item = card.itemContent
    if item = invalid then return
    if item.hasField("heroCard") then return
    if item.itemType = "folder" or item.itemType = "seeall" or m.page = "library" or m.page = "search" or m.page = "discover" then return
    focus = rows.rowItemFocused
    if type(focus) = "roArray" and focus.Count() > 0 and rows.content <> invalid
        row = rows.content.getChild(focus[0])
        if row <> invalid and row.id = "cw" then return
    end if
    meta = m.metaCache[item.metaId]
    m.cardItem = item
    expand = m.ui.expandOn and not (m.page = "home" and Home_Grid()) and not (m.page = "folder" and Bool_Of(m.libraryGrid, false))
    heroOk = m.page <> "home" or Home_Mode() = "modern"
    m.trailerToHero = heroOk and (m.ui.trailerTarget <> "card" or not expand)
    if expand then openExpanded(rows, item, meta)
    if m.ui.expandTrailer and (m.trailerToHero or expand) then startCardTrailer(item, meta)
end sub

sub openExpanded(rows as object, item as object, meta as dynamic)
    rect = Rows_FocusRect(rows)
    if rect = invalid then return
    h = rect.h
    toW = Int(rect.w * 2.66)
    x = rect.x
    if x + toW > 1880 then x = 1880 - toW
    hd = heroData(item, meta)
    background = hd.background
    if background = "" and Left(item.metaId, 2) = "tt" then background = Img_Background(item.metaId)
    parent = item.getParent()
    m.global.expandRow = parent
    idx = -1
    if item.hasField("idx")
        idx = item.idx
    else if parent <> invalid
        for i = 0 to parent.getChildCount() - 1
            if parent.getChild(i).isSameNode(item) then idx = i
        end for
    end if
    m.global.expandIndex = idx
    m.expanded.data = { x: x, y: rect.y, h: h, fromW: rect.w, toW: toW, background: background, logo: hd.logo, title: hd.title }
    m.expanded.open = true
    m.expandRows = rows
    rows.focusBitmapBlendColor = "0xFFFFFF00"
end sub

function Rows_FocusRect(rows as object) as dynamic
    focus = rows.rowItemFocused
    if type(focus) <> "roArray" or focus.Count() < 2 then return invalid
    row = focus[0]
    size = Arr_At(rows.rowItemSize, row)
    if type(size) <> "roArray" or size.Count() < 2 then return invalid
    offset = Arr_At(rows.rowLabelOffset, row)
    gap = 0
    if type(offset) = "roArray" and offset.Count() > 1 then gap = offset[1]
    shift = Arr_At(rows.focusXOffset, row)
    if shift = invalid then shift = 0
    x = 0
    y = 0
    node = rows
    while node <> invalid
        t = node.translation
        if type(t) = "roArray" and t.Count() > 1
            x = x + t[0]
            y = y + t[1]
        end if
        node = node.getParent()
    end while
    return { x: x + shift, y: y + Rows_LabelHeight(rows) + gap, w: size[0], h: size[1] }
end function

function Arr_At(list as dynamic, index as integer) as dynamic
    if type(list) <> "roArray" or list.Count() = 0 then return invalid
    if index >= list.Count() then index = list.Count() - 1
    if index < 0 then index = 0
    return list[index]
end function

function Rows_LabelHeight(rows as object) as integer
    if m.rowLabelH <> invalid then return m.rowLabelH
    h = 36
    probe = CreateObject("roSGNode", "Label")
    if rows.rowLabelFont <> invalid then probe.font = rows.rowLabelFont
    probe.text = "Ág"
    r = probe.boundingRect()
    if r <> invalid and r.height > 10 and r.height < 90 then h = Int(r.height)
    m.rowLabelH = h
    return h
end function

sub startCardTrailer(item as object, meta as dynamic)
    imdb = ""
    if Left(item.metaId, 2) = "tt" then imdb = item.metaId.Split(":")[0]
    task = CreateObject("roSGNode", "TrailerTask")
    if meta <> invalid
        if Str_Of(meta.imdb) <> "" then imdb = meta.imdb
        task.localYt = meta.trailerLocal
        task.ytIds = meta.trailerYt
        task.urls = meta.trailerUrls
    end if
    if imdb = "" and meta = invalid then return
    task.imdb = imdb
    task.kind = Str_Of(item.itemType)
    task.tag = item.metaId
    task.observeField("result", "onCardTrailer")
    task.control = "RUN"
    m.cardTask = task
end sub

sub onCardTrailer(event as object)
    task = event.getRoSGNode()
    if m.cardTask = invalid or not task.isSameNode(m.cardTask) then return
    m.cardTask = invalid
    r = task.result
    if r = invalid or Str_Of(r.url) = "" or m.cardItem = invalid then return
    if m.cardItem.metaId <> task.tag then return
    if m.trailerToHero
        if m.busy or m.area <> "page" or overlayOpen() then return
        m.heroTrailerOn = true
        m.hero.muted = m.ui.expandMuted
        full = {}
        full.Append(r)
        full.full = true
        m.hero.trailer = full
        return
    end if
    if not m.expanded.open then return
    m.expanded.muted = m.ui.expandMuted
    m.expanded.trailer = r
end sub

function Kb_Text(dlg as object) as string
    text = ""
    if dlg.hasField("text") then text = Str_Of(dlg.text)
    kb = invalid
    if dlg.hasField("keyboard") then kb = dlg.keyboard
    if text = "" and kb <> invalid
        if kb.hasField("text") then text = Str_Of(kb.text)
        if text = "" and kb.hasField("textEditBox") and kb.textEditBox <> invalid then text = Str_Of(kb.textEditBox.text)
    end if
    return text.Trim()
end function

sub Logo_Start(item as object)
    if m.logoTask <> invalid then m.logoTask.unobserveField("logo")
    m.logoTask = CreateObject("roSGNode", "LogoTask")
    m.logoTask.kind = item.itemType
    m.logoTask.metaId = item.metaId
    m.logoTask.observeField("logo", "onLogoFound")
    m.logoTask.control = "RUN"
end sub

sub onLogoFound(event as object)
    task = event.getRoSGNode()
    id = task.metaId
    logo = task.logo
    if m.logoCache = invalid then m.logoCache = {}
    if m.logoCache.Count() > 300 then m.logoCache = {}
    m.logoCache[id] = logo
    item = m.heroItem
    if item = invalid or item.metaId <> id or m.metaCache[id] <> invalid then return
    d = heroData(item, invalid)
    if logo <> "" then d.logo = logo
    m.hero.data = d
end sub

sub Update_Start()
    m.updateTask = CreateObject("roSGNode", "UpdateTask")
    m.updateTask.lang = Str_Of(m.global.uiLang)
    m.updateTask.seen = Str_Of(St_Get("updateSeen", ""))
    m.updateTask.observeField("result", "onUpdateResult")
    m.updateTask.control = "RUN"
end sub

sub onUpdateResult()
    r = m.updateTask.result
    m.updateTask = invalid
    if type(r) <> "roAssociativeArray" or Str_Of(r.version) = "" then return
    m.updateInfo = r
    m.updateTimer = CreateObject("roSGNode", "Timer")
    m.updateTimer.duration = 2
    m.updateTimer.repeat = true
    m.updateTimer.observeField("fire", "onUpdateTimer")
    m.updateTimer.control = "start"
    onUpdateTimer()
end sub

sub onUpdateTimer()
    if m.updateInfo = invalid or m.updatePrompt.visible then return
    if overlayOpen() or m.top.dialog <> invalid or m.page <> "home" then return
    m.updateTimer.control = "stop"
    m.updatePrompt.info = m.updateInfo
    m.updatePrompt.visible = true
    m.updatePrompt.setFocus(true)
end sub

sub onUpdateEvent()
    if m.updateInfo <> invalid then St_Set("updateSeen", Str_Of(m.updateInfo.tag))
    m.updateInfo = invalid
    m.updatePrompt.visible = false
    focusCurrent()
end sub

sub onHeroImmersive()
    if not m.hero.immersive
        Rows_Restore()
        return
    end if
    if Bool_Of(m.immersiveOn, false) then return
    if m.page <> "home" or m.area <> "page" or overlayOpen() or m.busy or not m.homeRows.isInFocusChain()
        Hero_EndImmersive()
        return
    end if
    m.immersiveOn = true
    m.expandTimer.control = "stop"
    m.homeRows.opacity = 0
    m.expanded.opacity = 0
    m.nav.opacity = 0
    m.top.setFocus(true)
end sub

sub Hero_EndImmersive()
    m.heroTrailerOn = false
    m.hero.trailer = {}
    Rows_Restore()
end sub

sub Rows_Restore()
    was = Bool_Of(m.immersiveOn, false)
    m.immersiveOn = false
    m.homeRows.opacity = 1
    m.expanded.opacity = 1
    m.nav.opacity = 1
    if was and (m.top.hasFocus() or m.hero.hasFocus()) then focusCurrent()
end sub

sub Progress_Soon()
    integ = St_Integrations()
    if integ.nuvioAccess = "" and Track_CwSource(integ) = "" and Track_LibSource(integ) = "" then return
    m.progressSoon.control = "stop"
    m.progressSoon.control = "start"
end sub

sub onProgressTimer()
    if m.accountTask <> invalid or m.pushTask <> invalid or m.progressTask <> invalid then return
    if m.player.visible or m.busy then return
    integ = St_Integrations()
    if integ.nuvioAccess = "" and Track_CwSource(integ) = "" and Track_LibSource(integ) = "" then return
    m.progressTask = CreateObject("roSGNode", "AccountTask")
    m.progressTask.mode = "nuvioProgress"
    m.progressTask.observeField("result", "onProgressRefreshed")
    m.progressTask.control = "RUN"
end sub

sub onProgressRefreshed(event as object)
    task = event.getRoSGNode()
    if m.progressTask = invalid or not task.isSameNode(m.progressTask) then return
    m.progressTask = invalid
    r = task.result
    if r = invalid or not Bool_Of(r.ok, false) then return
    m.watchedCache = invalid
    refreshContinueRow()
    if m.page = "library" then buildLibrary()
end sub

sub Ambient_Poke()
    if m.ambientClock <> invalid then m.ambientClock.Mark()
end sub

function Ambient_Allowed() as boolean
    if not Bool_Of(St_Pref("ambientOn"), false) then return false
    if not Bool_Of(m.homeLoaded, false) or m.busy or Bool_Of(m.immersiveOn, false) then return false
    if m.top.dialog <> invalid or overlayOpen() then return false
    pages = { home: true, library: true, folder: true, search: true, discover: true }
    return pages.DoesExist(Str_Of(m.page))
end function

sub onAmbientTimer()
    if m.ambient.active then return
    if not Ambient_Allowed()
        Ambient_Poke()
        return
    end if
    minutes = ToInt(St_Pref("ambientMinutes"), 5)
    if minutes < 1 then minutes = 1
    if m.ambientClock.TotalSeconds() < minutes * 60 then return
    slides = Ambient_Slides()
    if slides.Count() = 0
        Ambient_Poke()
        return
    end if
    hideExpanded()
    if Bool_Of(m.heroTrailerOn, false)
        m.heroTrailerOn = false
        m.hero.trailer = {}
    end if
    m.ambient.slides = slides
    m.ambient.active = true
end sub

sub Ambient_Close()
    if not m.ambient.active then return
    m.ambient.active = false
    Ambient_Poke()
    focusCurrent()
end sub

function Ambient_Slides() as object
    root = m.homeRows.content
    groups = []
    order = []
    if root <> invalid
        for i = 0 to root.getChildCount() - 1
            row = root.getChild(i)
            if row.id <> "cw"
                key = Home_RowKey(row)
                cut = Instr(1, key, "#")
                if cut > 0 then key = Left(key, cut - 1)
                index = -1
                for j = 0 to order.Count() - 1
                    if order[j] = key then index = j
                end for
                if index < 0 and order.Count() < 3
                    order.Push(key)
                    groups.Push([])
                    index = order.Count() - 1
                end if
                if index >= 0
                    for k = 0 to row.getChildCount() - 1
                        item = row.getChild(k)
                        if groups[index].Count() < 10 and item.itemType <> "folder" and item.itemType <> "seeall" then groups[index].Push(item)
                    end for
                end if
            end if
        end for
    end if
    picked = []
    seen = {}
    for n = 0 to 9
        for each g in groups
            if n < g.Count() and picked.Count() < 30
                item = g[n]
                id = Str_Of(item.metaId)
                if id = "" or not seen.DoesExist(id)
                    seen[id] = true
                    slide = Ambient_Slide(item)
                    if slide <> invalid then picked.Push(slide)
                end if
            end if
        end for
    end for
    for i = picked.Count() - 1 to 1 step -1
        j = Rnd(i + 1) - 1
        tmp = picked[i]
        picked[i] = picked[j]
        picked[j] = tmp
    end for
    return picked
end function

function Ambient_Slide(item as object) as dynamic
    meta = invalid
    if m.metaCache <> invalid then meta = m.metaCache[Str_Of(item.metaId)]
    background = Str_Of(item.background)
    if background = "" and meta <> invalid then background = Str_Of(meta.background)
    if background = "" and Left(Str_Of(item.metaId), 2) = "tt" then background = Img_Background(item.metaId)
    if background = "" then return invalid
    logo = Str_Of(item.logo)
    if meta <> invalid and Str_Of(meta.logo) <> "" then logo = meta.logo
    if logo = "" and Left(Str_Of(item.metaId), 2) = "tt" then logo = Img_Logo(item.metaId)
    if m.logoCache <> invalid and Str_Of(m.logoCache[item.metaId]) <> "" then logo = m.logoCache[item.metaId]
    genres = []
    if meta <> invalid and type(meta.genres) = "roArray"
        for each g in meta.genres
            if IsStr(g) and genres.Count() < 3 then genres.Push(g)
        end for
    end if
    return { background: background, logo: logo, title: Str_Of(item.title), genres: genres.Join("  •  ") }
end function

sub onGifCard()
    Gif_Hide()
    if m.global.gifCard = invalid or m.global.gifUrl = "" then return
    m.gifTimer.control = "stop"
    m.gifTimer.control = "start"
end sub

sub Gif_Hide()
    m.gifTimer.control = "stop"
    m.gifWait.control = "stop"
    m.gifLayer.visible = false
    if m.gifArt.uri <> ""
        m.gifArt.control = "stop"
        m.gifArt.uri = ""
    end if
end sub

sub Gif_Show()
    card = m.global.gifCard
    url = m.global.gifUrl
    if card = invalid or url = "" or overlayOpen() or m.top.dialog <> invalid then return
    w = Int(card.width)
    h = Int(card.height)
    if w <= 0 or h <= 0 then return
    spot = Gif_Spot(card)
    if spot = invalid then return
    m.gifLayer.translation = spot
    m.gifStage = 0
    m.gifArt.translation = [6, 6]
    m.gifArt.width = w - 12
    m.gifArt.height = h - 12
    m.gifArt.loadWidth = w - 12
    m.gifArt.loadHeight = h - 12
    m.gifRing.width = w
    m.gifRing.height = h
    m.gifRing.blendColor = m.accent
    Mask_Apply(m.top.findNode("gifMask"), w, h)
    gifBack = m.top.findNode("gifBack")
    gifBack.width = w
    gifBack.height = h
    Mask_Caps(m.top.findNode("gifCaps"), w, h, 22, "0x0C0C0FFF")
    low = LCase(url)
    if Instr(1, low, "giphy.com") > 0 and Instr(1, low, ".mp4") > 0 then url = url.Replace(".mp4", ".gif")
    if Instr(1, LCase(url), ".mp4") > 0 then return
    m.gifUrl = url
    m.gifSize = [w - 12, h - 12]
    if Instr(1, LCase(url), "postimg.cc") > 0 then m.gifStage = 1
    Gif_Load()
end sub

sub Gif_Load()
    m.gifWait.control = "stop"
    m.gifArt.control = "stop"
    w = m.gifSize[0].ToStr()
    h = m.gifSize[1].ToStr()
    source = m.gifUrl
    if m.gifStage = 1 or m.gifStage = 2 then source = "https://external-content.duckduckgo.com/iu/?u=" + m.gifUrl.EncodeUriComponent()
    base = "https://wsrv.nl/?url=" + source.EncodeUriComponent() + "&output=webp&w=" + w + "&h=" + h + "&fit=cover"
    if m.gifStage = 3
        m.gifArt.mimeType = "image/gif"
        if Instr(1, LCase(m.gifUrl), ".webp") > 0 then m.gifArt.mimeType = "video/webp"
        m.gifArt.uri = m.gifUrl
    else if m.gifStage = 2
        m.gifArt.mimeType = "video/webp"
        m.gifArt.uri = base + "&n=40&q=70"
    else
        m.gifArt.mimeType = "video/webp"
        m.gifArt.uri = base + "&n=-1"
    end if
    m.gifWait.control = "start"
    m.gifArt.control = "loop"
end sub

sub onGifWait()
    st = m.gifArt.state
    if st = "downloading" or st = "init" or st = "" or st = "error" then Gif_Next()
end sub

sub Gif_Next()
    if m.gifUrl = "" or m.gifStage >= 3 then return
    m.gifStage = m.gifStage + 1
    Gif_Load()
end sub

function Gif_Spot(card as object) as dynamic
    rows = activeRows()
    if rows = invalid or not rows.hasFocus()
        rows = card.getParent()
        while rows <> invalid and rows.subtype() <> "RowList"
            rows = rows.getParent()
        end while
    end if
    if rows = invalid then return invalid
    focus = rows.rowItemFocused
    if type(focus) <> "roArray" or focus.Count() < 2 then return invalid
    x = 0
    y = 0
    node = rows
    while node <> invalid
        t = node.translation
        if type(t) = "roArray" and t.Count() > 1
            x = x + t[0]
            y = y + t[1]
        end if
        node = node.getParent()
    end while
    shift = Arr_At(rows.focusXOffset, focus[0])
    if shift <> invalid then x = x + shift
    if rows.rowFocusAnimationStyle = "floatingFocus"
        gap = Arr_At(rows.rowItemSpacing, focus[0])
        space = 0
        if type(gap) = "roArray" and gap.Count() > 0 then space = gap[0]
        x = x + focus[1] * (card.width + space)
    end if
    label = Arr_At(rows.showRowLabel, focus[0])
    if label = invalid or label = true
        y = y + Rows_LabelHeight(rows)
        offset = Arr_At(rows.rowLabelOffset, focus[0])
        if type(offset) = "roArray" and offset.Count() > 1 then y = y + offset[1]
    end if
    return [x, y]
end function

sub onGifArtState()
    st = m.gifArt.state
    if st = "error" and m.gifStage < 3
        Gif_Next()
        return
    end if
    if st <> "downloading" and st <> "init" and st <> "" then m.gifWait.control = "stop"
    playing = m.gifArt.uri <> "" and st <> "downloading" and st <> "init" and st <> "error" and st <> "" and st <> "stopped"
    m.gifLayer.visible = playing and m.global.gifCard <> invalid and not overlayOpen()
end sub


sub startStremioStore()
    if m.addonStoreTask <> invalid then return
    showBusy("Loading the Stremio Addons directory...")
    m.addonStoreTask = CreateObject("roSGNode", "AddonStoreTask")
    if m.addonStoreTask = invalid
        hideBusy()
        showMessage("Store unavailable", "The add-on directory task could not be created.")
        return
    end if
    m.addonStoreTask.observeField("result", "onAddonStoreResult")
    m.addonStoreTask.control = "RUN"
end sub

sub onAddonStoreResult(event as object)
    task = event.getRoSGNode()
    if m.addonStoreTask = invalid or not task.isSameNode(m.addonStoreTask) then return
    m.addonStoreTask = invalid
    hideBusy()
    result = task.result
    if type(result) <> "roAssociativeArray" or not Bool_Of(result.ok, false)
        message = "The Stremio Addons directory could not be loaded. Check the Roku internet connection and try again."
        if type(result) = "roAssociativeArray" and Str_Of(result.error) <> "" then message = result.error
        showMessage("Store unavailable", message)
        return
    end if
    if type(result.items) <> "roArray" or result.items.Count() = 0
        showMessage("No compatible add-ons", "The directory did not return any Movies & TV add-ons for this Roku build.")
        return
    end if
    m.storeItems = result.items
    m.storeSearch = ""
    openMenu("stremioStoreResults", {})
end sub

sub installStoreAddon(index as integer)
    if type(m.storeItems) <> "roArray" or index < 0 or index >= m.storeItems.Count()
        showMessage("Add-on unavailable", "This directory entry is no longer available. Refresh the store and try again.")
        return
    end if
    item = m.storeItems[index]
    if Bool_Of(item.requiresConfig, false)
        showMessage("Configuration required", "Configure this add-on first, then add its final manifest URL.")
        return
    end if
    url = Str_Of(item.manifestUrl)
    if url = "" then url = Str_Of(item.url)
    if url = ""
        showMessage("Invalid add-on", "The directory entry did not contain a manifest URL.")
        return
    end if
    normalized = St_NormalizeUrl(url)
    for each installed in St_Addons()
        if LCase(installed) = LCase(normalized)
            showMessage("Already installed", Str_Of(item.name) + " is already in your add-on list.")
            return
        end if
    end for
    if m.addonInstallTask <> invalid
        Toast_Show("An add-on check is already running. Please wait.")
        return
    end if
    Toast_Show("Checking add-on compatibility in the background...")
    m.addonInstallTask = CreateObject("roSGNode", "AddonInstallTask")
    if m.addonInstallTask = invalid
        showMessage("Install unavailable", "The add-on validation task could not be created.")
        return
    end if
    m.addonInstallTask.url = normalized
    m.addonInstallTask.observeField("result", "onAddonInstallValidated")
    m.addonInstallTask.control = "RUN"
end sub

sub onAddonInstallValidated(event as object)
    task = event.getRoSGNode()
    if m.addonInstallTask = invalid or not task.isSameNode(m.addonInstallTask) then return
    m.addonInstallTask = invalid
    result = task.result
    if type(result) <> "roAssociativeArray" or not Bool_Of(result.ok, false)
        message = "The add-on manifest could not be verified."
        if type(result) = "roAssociativeArray" and Str_Of(result.error) <> "" then message = result.error
        showMessage("Could not install", message)
        return
    end if
    url = Str_Of(result.url)
    name = Str_Of(result.name)
    if name = "" then name = url
    if not St_AddAddon(url)
        showMessage("Could not install", "This add-on is already installed or its address is invalid.")
        return
    end if
    m.needsReload = true
    m.stack.Clear()
    m.list.visible = false
    message = name + " was added. Return to Home to refresh its catalogues in the background."
    if Bool_Of(result.hasStream, false) = false
        message = name + " was added as a catalogue/metadata provider. It does not advertise direct stream support."
    end if
    showMessage("Add-on installed", message)
end sub


sub startStorageLoad()
    if m.storageLoadTask <> invalid then return
    m.storageLoadTask = CreateObject("roSGNode", "StorageTask")
    if m.storageLoadTask = invalid
        m.global.storageCache = {}
        m.global.storageRegistry = {}
        m.storageReady = true
        if m.bootReadyPending then onBootReady()
        return
    end if
    m.storageLoadTask.mode = "load"
    m.storageLoadTask.observeField("result", "onStorageLoaded")
    m.storageLoadTask.observeField("state", "onStorageLoadState")
    m.storageLoadTask.control = "RUN"
end sub

sub applyStorageResult(result as dynamic)
    files = {}
    registry = {}
    if type(result) = "roAssociativeArray"
        if type(result.files) = "roAssociativeArray" then files = result.files
        if type(result.registry) = "roAssociativeArray" then registry = result.registry
    end if

    ' Preserve any writes made while the disk snapshot was being loaded.
    currentFiles = m.global.storageCache
    if type(currentFiles) = "roAssociativeArray"
        for each key in currentFiles.Keys()
            files[key] = currentFiles[key]
        end for
    end if
    currentRegistry = m.global.storageRegistry
    if type(currentRegistry) = "roAssociativeArray"
        for each key in currentRegistry.Keys()
            registry[key] = currentRegistry[key]
        end for
    end if
    pending = m.global.storageQueue
    if type(pending) = "roArray"
        for each command in pending
            if type(command) = "roAssociativeArray"
                if command.op = "fileDelete"
                    if files.DoesExist(command.name) then files.Delete(command.name)
                else if command.op = "registryDelete"
                    if registry.DoesExist(command.key) then registry.Delete(command.key)
                end if
            end if
        end for
    end if

    m.global.storageCache = files
    m.global.storageRegistry = registry
    m.storageReady = true
end sub

sub onStorageLoaded()
    if m.storageReady or m.storageLoadTask = invalid then return
    applyStorageResult(m.storageLoadTask.result)
    m.storageLoadTask.unobserveField("result")
    m.storageLoadTask.unobserveField("state")
    m.storageLoadTask = invalid
    onStorageQueue()
    if m.bootReadyPending then onBootReady()
end sub

sub onStorageLoadState()
    if m.storageLoadTask = invalid or m.storageReady then return
    state = m.storageLoadTask.state
    if state = "done" or state = "stop"
        ' The Task result is assigned before completion. Read it here too so
        ' an event-order difference cannot drop saved settings or stall boot.
        applyStorageResult(m.storageLoadTask.result)
        m.storageLoadTask.unobserveField("result")
        m.storageLoadTask.unobserveField("state")
        m.storageLoadTask = invalid
        onStorageQueue()
        if m.bootReadyPending then onBootReady()
    end if
end sub

sub onStorageQueue()
    if not m.storageReady then return
    if m.storageWriteTask <> invalid then return
    queue = m.global.storageQueue
    if type(queue) <> "roArray" or queue.Count() = 0 then return

    m.global.storageQueue = []
    m.storageWriteTask = CreateObject("roSGNode", "StorageTask")
    if m.storageWriteTask = invalid then return
    m.storageWriteTask.mode = "write"
    m.storageWriteTask.commands = queue
    m.storageWriteTask.observeField("state", "onStorageWriteState")
    m.storageWriteTask.control = "RUN"
end sub

sub onStorageWriteState()
    if m.storageWriteTask = invalid then return
    state = m.storageWriteTask.state
    if state = "done" or state = "stop"
        m.storageWriteTask.unobserveField("state")
        m.storageWriteTask = invalid
        onStorageQueue()
    end if
end sub
